// Function to request notification permission
function requestNotificationPermission() {
  if (Notification.permission === "granted") {
    return Promise.resolve();
  } else if (Notification.permission === "denied") {
    alert("You have denied notifications. Please enable them in your browser settings.");
    return Promise.reject();
  } else {
    return Notification.requestPermission();
  }
}

// Function to set reminder for an event
function setReminder(eventName, eventDate) {
  const reminderTime = new Date(eventDate).getTime() - 60000; // 1 minute before the event

  // Only set reminder if the event is in the future
  if (reminderTime > Date.now()) {
    requestNotificationPermission().then(() => {
      setTimeout(() => {
        showReminder(eventName);
      }, reminderTime - Date.now()); // Trigger notification at the reminder time
    }).catch(() => {});
  } else {
    alert("The event time is in the past. Reminder cannot be set.");
  }
}

// Function to show reminder notification
function showReminder(eventName) {
  const notification = new Notification("Event Reminder", {
    body: `Don't forget the event: ${eventName}`,
    icon: "https://via.placeholder.com/150", // You can replace this with your app icon
  });
  notification.onclick = () => {
    window.focus();
  };
}

// Function to add a new event (simulated with localStorage for this example)
function addEvent() {
  const eventName = document.getElementById('eventName').value;
  const eventDate = document.getElementById('eventDate').value;
  const eventDescription = document.getElementById('eventDescription').value;

  if (eventName && eventDate && eventDescription) {
    const newEvent = { eventName, eventDate, eventDescription };
    
    // Save the new event in localStorage
    let events = JSON.parse(localStorage.getItem('events')) || [];
    events.push(newEvent);
    localStorage.setItem('events', JSON.stringify(events));
    
    alert(`Event "${eventName}" added successfully!`);
    window.location.href = 'index.html'; // Redirect to the event list page
  } else {
    alert('Please fill in all fields');
  }
}

// Function to display events from localStorage
function displayEvents() {
  const events = JSON.parse(localStorage.getItem('events')) || [];
  const eventList = document.getElementById('eventList');

  events.forEach(event => {
    const eventItem = document.createElement('li');
    eventItem.classList.add('event-item');
    
    const eventDetails = document.createElement('div');
    eventDetails.innerHTML = `
      <p class="event-name">${event.eventName}</p>
      <p class="event-date">${event.eventDate}</p>
    `;
    
    const reminderButton = document.createElement('button');
    reminderButton.classList.add('reminder-btn');
    reminderButton.textContent = "Set Reminder";
    reminderButton.onclick = () => setReminder(event.eventName, event.eventDate);

    eventItem.appendChild(eventDetails);
    eventItem.appendChild(reminderButton);
    eventList.appendChild(eventItem);
  });
}

// Run this function on page load to display events
window.onload = function() {
  if (document.getElementById('eventList')) {
    displayEvents();
  }
};

// Redirect to add event page
function goToAddEventPage() {
  window.location.href = "add-event.html";
}

// Handle the back button on the form page
function goBack() {
  window.history.back();
}
